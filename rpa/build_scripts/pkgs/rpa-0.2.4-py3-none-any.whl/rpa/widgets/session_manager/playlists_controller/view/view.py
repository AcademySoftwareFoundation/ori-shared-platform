from PySide2 import QtCore, QtGui, QtWidgets
from rpa.widgets.session_manager.playlists_controller.view.item_delegate \
    import ItemDelegate
from rpa.widgets.session_manager.playlists_controller.view.style \
    import Style


class View(QtWidgets.QListView):
    SIG_CONTEXT_MENU_REQUESTED = QtCore.Signal(object, QtCore.QPoint)
    SIG_SET_FG = QtCore.Signal(str) # playlist_id
    SIG_SET_BG = QtCore.Signal(str) # playlist_id
    SIG_DELETE = QtCore.Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        # self.setHeaderHidden(True)
        self.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.setItemDelegate(ItemDelegate(self))
        self.setEnabled(True)
        self.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)

    def setModel(self, model):
        super().setModel(model)

    def contextMenuEvent(self, event):
        mindex = self.indexAt(event.pos())
        global_pos = self.mapToGlobal(event.pos())
        self.SIG_CONTEXT_MENU_REQUESTED.emit(mindex, global_pos)

    def mousePressEvent(self, event):
        index = self.indexAt(event.pos())
        id = self.model().playlist_ids[index.row()]

        if event.button() == QtCore.Qt.LeftButton:
            if index.isValid():
                if event.modifiers() & QtCore.Qt.ControlModifier:
                    self.selectionModel().select(index, QtCore.QItemSelectionModel.Toggle)
                    return
                elif event.modifiers() & QtCore.Qt.ShiftModifier:
                    super().mousePressEvent(event)
                elif event.modifiers() & QtCore.Qt.AltModifier:
                    self.SIG_SET_BG.emit(id)
                else:
                    self.SIG_SET_FG.emit(id)
            else:
                super().mousePressEvent(event)

        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event: QtGui.QMouseEvent) -> None:
        index = self.indexAt(event.pos())
        if index.isValid():
            self.edit(index)
        super().mouseDoubleClickEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.MiddleButton:
            index = self.indexAt(event.pos())
            if index.isValid():
                self.SIG_DELETE.emit()
        super().mouseReleaseEvent(event)

    def rename_requested(self, index):
        self.edit(index)

    def get_selected_mindexes(self):
        return self.selectionModel().selectedIndexes()

    def get_selected_indexes(self):
        mindexes = self.selectionModel().selectedRows()
        return [mindex.row() for mindex in mindexes]
