try:
    from PySide2 import QtGui
except ImportError:
    from PySide6 import QtGui

WHITE = QtGui.QColor(255.0, 255.0, 255.0)
BLACK = QtGui.QColor(0, 0, 0)
RED = QtGui.QColor(255.0, 0, 0)
GREEN = QtGui.QColor(0, 255.0, 0)
BLUE = QtGui.QColor(0, 0, 255.0)
GOLDEN_ROD = QtGui.QColor(192.0, 158.0, 64.0)
