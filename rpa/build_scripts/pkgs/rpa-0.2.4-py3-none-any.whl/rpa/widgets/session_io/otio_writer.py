import os
import re
import opentimelineio as otio
import rpa.widgets.session_io.constants as C

class OTIOWriter(object):

    def __init__(self, rpa, dbid_mapper, main_window):
        super().__init__()

        self.__dbid_mapper = dbid_mapper
        self.__session_api = rpa.session_api
        self.__status_bar = main_window.get_status_bar()

    def write_otio_file(self, file_path:str):
        timeline = otio.schema.Timeline()

        playlist_ids = self.__session_api.get_playlists()
        for playlist_id in playlist_ids:
            track = self.__create_otio_track(playlist_id)

            clip_ids = self.__session_api.get_clips(playlist_id)
            for clip_id in clip_ids:
                clip = self.__create_otio_clip(playlist_id, clip_id)
                track.append(clip)

            timeline.tracks.append(track)

        timeline.name = os.path.splitext(os.path.basename(file_path))[0]
        success = otio.adapters.write_to_file(timeline, file_path)
        if success:
            self.__status_bar.showMessage(
                f"Current session saved successfully in {file_path}", 3000)

    def __create_otio_track(self, playlist_id:str):
        playlist_name = self.__session_api.get_playlist_name(playlist_id)
        playlist_metadata = self.__get_playlist_metadata(playlist_id)

        track = otio.schema.Track(
            name=playlist_name,
            kind=otio.schema.TrackKind.Video
        )
        track.metadata[C.ITVIEW_METADATA_KEY] = playlist_metadata

        return track

    def __get_playlist_metadata(self, playlist_id:str):
        playlist_metadata = {}
        fg_playlist_id = self.__session_api.get_fg_playlist()
        bg_playlist_id = self.__session_api.get_bg_playlist()

        if playlist_id == fg_playlist_id:
            playlist_metadata["foreground"] = True
        if playlist_id == bg_playlist_id:
            playlist_metadata["background"] = True

        return playlist_metadata

    def __create_otio_clip(self, playlist_id:str, clip_id:str):
        media_reference = self.__create_media_reference(playlist_id, clip_id)
        clip_name = self.__get_clip_name(clip_id)
        clip_metadata = self.__get_clip_metadata(playlist_id, clip_id)

        key_in = self.__session_api.get_attr_value(clip_id, "key_in")
        key_out = self.__session_api.get_attr_value(clip_id, "key_out")
        video_fps = self.__session_api.get_attr_value(clip_id, "media_fps")
        start_frame = self.__session_api.get_attr_value(clip_id, "media_start_frame")
        end_frame = self.__session_api.get_attr_value(clip_id, "media_end_frame")

        if start_frame == key_in and end_frame == key_out:
            source_range = None
        else:
            source_range = self.__get_time_range(key_in, key_out, video_fps)
        source_range = self.__get_time_range(key_in, key_out, video_fps)

        clip = otio.schema.Clip(
            name=clip_name,
            media_reference=media_reference,
            source_range=source_range
        )
        clip.metadata[C.ITVIEW_METADATA_KEY] = clip_metadata

        return clip

    def __create_media_reference(self, playlist_id:str, clip_id:str):
        video_path = self.__session_api.get_attr_value(clip_id, "media_path")
        video_fps = self.__session_api.get_attr_value(clip_id, "media_fps")
        start_frame = self.__session_api.get_attr_value(clip_id, "media_start_frame")
        end_frame = self.__session_api.get_attr_value(clip_id, "media_start_frame")

        available_range = self.__get_time_range(start_frame, end_frame, video_fps)
        is_img_seq, frame_zero_padding = self.__is_image_sequence(video_path)

        if is_img_seq:
            media_ref = otio.schema.ImageSequenceReference(
                target_url_base=video_path,
                available_range=available_range,
                frame_zero_padding=frame_zero_padding
            )
        else:
            media_ref = otio.schema.ExternalReference(
                target_url=video_path,
                available_range=available_range
            )

        return media_ref

    def __get_time_range(self, start_frame:int, end_frame:int, fps:float):
        start_time, duration = \
            self.frames_to_otio_rational_times(start_frame, end_frame, fps)

        if not start_time or not duration:
            return None

        time_range = otio.opentime.TimeRange(
            start_time=start_time,
            duration=duration
        )
        return time_range

    def frames_to_otio_rational_times(self, start_frame:int, end_frame:int, fps:float):
        if start_frame is None or end_frame is None or not fps:
            return None, None

        start_time = otio.opentime.RationalTime(start_frame, rate=fps)
        end_time_inclusive = otio.opentime.RationalTime(end_frame, rate=fps)
        duration = otio.opentime.RationalTime.duration_from_start_end_time_inclusive(
            start_time, end_time_inclusive)
        return start_time, duration

    def __is_image_sequence(self, media_path:str):
        basename = os.path.basename(media_path)
        frame_zero_padding = None
        image_seq_pattern = re.findall("\.%0\d+d\.", basename)
        if image_seq_pattern:
            frame_zero_padding = int(re.search("\d+", image_seq_pattern[0]).group(0))
        else:
            image_seq_pattern = re.findall("\.\d+-\d+#|@+", basename)
            if image_seq_pattern:
                pattern = re.search("#|@+", image_seq_pattern[0]).group(0)
                frame_zero_padding = 4 if "#" in pattern else len(pattern)

        return (len(image_seq_pattern) == 1, frame_zero_padding)

    def __get_clip_name(self, clip_id:str):
        dbid = self.__dbid_mapper.get_dbid(clip_id)
        clip_name = str(dbid) if dbid else ""
        return clip_name

    def __get_clip_metadata(self, playlist_id:str, clip_id:str):
        clip_metadata = {}
        rw_attrs = self.__session_api.get_read_write_attrs()
        keyable_attrs = self.__session_api.get_keyable_attrs()

        for rw_attr in rw_attrs:
            if rw_attr == "sg_alt": # skip sg_alt since it will update from sg
                continue
            default_attr_value = self.__session_api.get_default_attr_value(rw_attr)
            attr_value = self.__session_api.get_attr_value(clip_id, rw_attr)
            if attr_value != default_attr_value:
                clip_metadata[rw_attr] = attr_value

        for keyable_attr in keyable_attrs:
            default_attr_value = self.__session_api.get_default_attr_value(keyable_attr)
            attr_value = self.__session_api.get_attr_value(clip_id, keyable_attr)
            if attr_value != default_attr_value:
                key_values_only = {}
                key_values_only["key_values"] = attr_value.get("key_values")
                clip_metadata[keyable_attr] = str(key_values_only)

        return clip_metadata
