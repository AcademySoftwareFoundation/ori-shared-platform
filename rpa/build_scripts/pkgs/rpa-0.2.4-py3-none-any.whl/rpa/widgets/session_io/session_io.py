import os
from PySide2 import QtCore, QtWidgets
from rpa.widgets.session_io.otio_reader import OTIOReader
from rpa.widgets.session_io.otio_writer import OTIOWriter


class SessionIO(QtCore.QObject):

    SIG_APPEND_SESSION = QtCore.Signal()
    SIG_REPLACE_SESSION = QtCore.Signal()
    SIG_SAVE_SESSION = QtCore.Signal()

    def __init__(self, rpa, dbid_mapper, main_window):
        super().__init__()

        self.__rpa = rpa
        self.__dbid_mapper = dbid_mapper
        self.__main_window = main_window

        self.__otio_reader = OTIOReader(self.__rpa, self.__main_window)
        self.__otio_writer = OTIOWriter(self.__rpa, self.__dbid_mapper, self.__main_window)

        self.__init_actions()
        self.__connect_signals()

    @property
    def otio_reader(self):
        return self.__otio_reader

    @property
    def otio_writer(self):
        return self.__otio_writer

    def __init_actions(self):
        self.append_session_action = QtWidgets.QAction("Append Session")
        self.append_session_action.setStatusTip("Append a session file to the current session")

        self.replace_session_action = QtWidgets.QAction("Replace Session")
        self.replace_session_action.setStatusTip("Replace the current session with a session file")

        self.save_session_action = QtWidgets.QAction("Save Session")
        self.save_session_action.setStatusTip("Save the current session to a file")

    def __connect_signals(self):
        self.append_session_action.triggered.connect(self.__append_session)
        self.replace_session_action.triggered.connect(self.__replace_session)
        self.save_session_action.triggered.connect(self.__save_session)

    def __append_session(self):
        self.SIG_APPEND_SESSION.emit()

    def __replace_session(self):
        self.SIG_REPLACE_SESSION.emit()

    def __save_session(self):
        self.SIG_SAVE_SESSION.emit()
