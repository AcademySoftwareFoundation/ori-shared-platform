OTIO_EXT = ".otio"

# file dialog mode
APPEND = "append"
REPLACE = "replace"
SAVE = "save"

ITVIEW_METADATA_KEY = "itview"
