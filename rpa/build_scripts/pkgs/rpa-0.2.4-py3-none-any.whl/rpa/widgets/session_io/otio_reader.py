import ast
import uuid
import opentimelineio as otio
import rpa.widgets.session_io.constants as C


class OTIOReader(object):

    def __init__(self, rpa, main_window):
        super().__init__()

        self.__session_api = rpa.session_api
        self.__status_bar = main_window.get_status_bar()

    def read_otio_file(self, file_path):
        otio_timeline = otio.adapters.read_from_file(file_path)
        success = self.__create_session_from_otio(otio_timeline)
        if success:
            self.__status_bar.showMessage(
                f"Loaded session from {file_path}", 3000)
        else:
            self.__status_bar.showMessage(
                f"Failed to load session from {file_path}", 3000)

    def __create_session_from_otio(self, otio_timeline):
        timeline_name = otio_timeline.name
        fg_playlist_id = None
        bg_playlist_id = None
        rw_attrs_to_set = []
        keyable_attrs_to_set = []

        try:
            tracks = otio_timeline.tracks
            for track in tracks:
                playlist_name = track.name if track.name else ""
                playlist_id = self.__session_api.create_playlists([playlist_name])[0]

                playlist_metadata = track.metadata.get(C.ITVIEW_METADATA_KEY)
                is_fg = playlist_metadata.get("foreground", None)
                is_bg = playlist_metadata.get("background", None)
                if is_fg:
                    fg_playlist_id = playlist_id
                if is_bg:
                    bg_playlist_id = playlist_id

                clip_ids = []
                clip_paths = []

                for clip in track:
                    dbid = clip.name if clip.name else ""
                    clip_media = clip.media_reference.target_url

                    if clip_media is None:
                        continue

                    clip_id = uuid.uuid4().hex
                    clip_ids.append(clip_id)
                    clip_paths.append(clip_media)
                    clip_attr_values = clip.metadata[C.ITVIEW_METADATA_KEY]

                    for attr_id, value in clip_attr_values.items():
                        if self.__session_api.is_keyable(attr_id):
                            value = ast.literal_eval(value) # str to dict
                            keys = value.get("key_values")
                            for key, dynamic_value in keys.items():
                                keyable_attrs_to_set.append((playlist_id, clip_id, attr_id, key, dynamic_value))
                        else:
                            rw_attrs_to_set.append((playlist_id, clip_id, attr_id, value))

                self.__session_api.create_clips(playlist_id, clip_paths, ids=clip_ids)

            if rw_attrs_to_set:
                self.__session_api.set_attr_values(rw_attrs_to_set)
            if keyable_attrs_to_set:
                self.__session_api.set_attr_values_at(keyable_attrs_to_set)

            if fg_playlist_id is not None:
                self.__session_api.set_fg_playlist(fg_playlist_id)
            if bg_playlist_id is not None:
                self.__session_api.set_bg_playlist(bg_playlist_id)

            return True

        except Exception as exception:
            print(f"Failed to load {timeline_name}: {exception}")
            return False
