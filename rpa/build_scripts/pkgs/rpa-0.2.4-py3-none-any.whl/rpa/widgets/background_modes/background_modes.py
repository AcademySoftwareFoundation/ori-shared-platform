from PySide2 import QtCore, QtGui, QtWidgets
from rpa.widgets.background_modes.actions import Actions
import os
from rpa.session_state.annotations import Annotation
from rpa.session_state.color_corrections import ColorCorrection
import uuid


class BackgroundModes(QtCore.QObject):
    def __init__(self, rpa, main_window):
        self.__rpa = rpa
        self.__main_window = main_window

        self.__session_api = self.__rpa.session_api
        self.__timeline_api = self.__rpa.timeline_api

        self.actions = Actions()
        self.__connect_signals()

        self.__mode_to_action = {
            1: self.actions.wipe,
            2: self.actions.side_by_side,
            3: self.actions.top_to_bottom,
            4: self.actions.pip}

        self.__session_api.delegate_mngr.add_post_delegate(
            self.__session_api.set_bg_mode, self.__bg_mode_changed)

        self.__session_api.SIG_BG_PLAYLIST_CHANGED.connect(
            self.__bg_playlist_changed)

        self.__bg_mode_changed(True, self.__session_api.get_bg_mode())
        self.__bg_playlist_changed(self.__session_api.get_bg_playlist())

    def __connect_signals(self):
        self.actions.turn_off_background.triggered.connect(
            self.__turn_off_background)
        self.actions.wipe_current_frame.triggered.connect(
            self.__wipe_current_frame)
        self.actions.pip.triggered.connect(self.__toggle_pip)
        self.actions.side_by_side.triggered.connect(self.__toggle_side_by_side)
        self.actions.top_to_bottom.triggered.connect(self.__toggle_top_to_bottom)
        self.actions.wipe.triggered.connect(self.__toggle_wipe)
        self.actions.swap_background.triggered.connect(self.__swap_background)

    def __turn_off_background(self):
        self.__session_api.set_bg_playlist(None)

    def __wipe_current_frame(self):
        fg_playlist = self.__session_api.get_fg_playlist()
        playlist_name = self.__session_api.get_playlist_name(fg_playlist)
        [playlist_id_for_wipe] = self.__session_api.create_playlists([f'{playlist_name}_playlist_for_wipe'])
        clip_data = self.__get_clip_data(
            self.__session_api.get_fg_playlist(),
            self.__session_api.get_current_clip())
        self.__create_clip(playlist_id_for_wipe, clip_data)
        [clip_id_for_wipe] = self.__session_api.get_clips(playlist_id_for_wipe)
        current_frame = self.__timeline_api.get_current_frame(clip_mode=True)
        self.__session_api.set_attr_values([
            (playlist_id_for_wipe, clip_id_for_wipe, "key_in", current_frame),
            (playlist_id_for_wipe, clip_id_for_wipe, "key_out", current_frame)
        ])
        self.__session_api.set_bg_playlist(playlist_id_for_wipe)

    def __create_clip(self, playlist, clip_data):
        media_paths = []

        attrs = clip_data.get("attrs")
        jts = attrs.get("sg_jts")
        if jts:
            show = attrs.get("sg_vfo_show", os.environ.get("SHOW", "spi"))
            media_paths.append(f"{show}-{jts}")
        else:
            media_paths.append(attrs.get("media_path"))

        clips = self.__rpa.session_api.get_clips(playlist)
        if not clips: index = 0
        else:
            selected_clips = self.__rpa.session_api.get_active_clips(playlist)
            if selected_clips: index = clips.index(selected_clips[-1])
            else: index = len(clips) - 1

        clip_ids = self.__rpa.session_api.create_clips(
            playlist, media_paths, index + 1)

        cnt = 0
        attr_values = []
        ro_annos = {}
        rw_annos = {}
        ro_ccs = {}
        rw_ccs = {}

        clip_id = clip_ids[cnt]
        cnt += 1

        attrs = clip_data.get("attrs")
        for attr_id, value in attrs.items():
            if attr_id in ["sg_jts", "media_path"]: continue
            attr_values.append((playlist, clip_id,  attr_id, value))

        custom_attrs = clip_data.get("custom_attrs")
        if custom_attrs:
            for attr_id, value in custom_attrs.items():
                self.__rpa.session_api.set_custom_clip_attr(attr_id, value)

        if clip_data.get("annotations"):
            if clip_data["annotations"].get("ro"):
                for frame, annos in clip_data["annotations"]["ro"].items():
                    annos = [Annotation().__setstate__(anno) for anno in annos]
                    ro_annos.setdefault(clip_id, {})[frame] = annos

            if clip_data["annotations"].get("rw"):
                for frame, anno in clip_data["annotations"]["rw"].items():
                    rw_annos.setdefault(clip_id, {})[frame] = \
                        Annotation().__setstate__(anno)

        if clip_data.get("color_corrections"):
            if clip_data["color_corrections"].get("ro"):
                for frame, ccs in clip_data["color_corrections"]["ro"]:
                    cc_objects = []
                    for cc in ccs:
                        color_correction = ColorCorrection()
                        color_correction.__setstate__(cc)
                        color_correction.id = uuid.uuid4().hex
                        cc_objects.append(color_correction)
                    ro_ccs.setdefault(clip_id, []).append((frame, cc_objects))

            if clip_data["color_corrections"].get("rw"):
                for frame, cc in clip_data["color_corrections"]["rw"]:
                    cc["id"] = uuid.uuid4().hex
                    rw_ccs.setdefault(clip_id, []).append(
                        (frame, ColorCorrection().__setstate__(cc)))

        self.__rpa.session_api.set_attr_values(attr_values)
        if ro_annos: self.__rpa.annotation_api.set_ro_annotations(ro_annos)
        if rw_annos: self.__rpa.annotation_api.set_rw_annotations(rw_annos)
        if ro_ccs: self.__rpa.color_api.set_ro_ccs(ro_ccs)
        if rw_ccs: self.__rpa.color_api.set_rw_ccs(rw_ccs)

    def __get_clip_data(self, playlist, clip):
        clip_data = {}
        print("++++++++++ clip", clip)

        # Attrs
        attr_values = {}
        for attr_id, metadata in \
        self.__rpa.session_api.get_attrs_metadata().items():
            if metadata.get("is_read_only", True): continue
            attr_values[attr_id] = self.__rpa.session_api.get_attr_value(
                clip, attr_id)
        media_path_attr_ids = ["media_path", "sg_jts"]
        for attr_id in media_path_attr_ids:
            attr_values[attr_id] = self.__rpa.session_api.get_attr_value(
                clip, attr_id)
        clip_data["attrs"] = attr_values

        # Custom Attrs
        for attr_id in self.__rpa.session_api.get_custom_clip_attr_ids(clip):
            clip_data.setdefault("custom_attrs", {})[attr_id] = \
                self.__rpa.session_api.get_custom_clip_attr(clip, attr_id)

        # Annotations
        for frame in self.__rpa.annotation_api.get_ro_frames(clip):
            ro_annos = \
                self.__rpa.annotation_api.get_ro_annotations(clip, frame)
            ro_annos = [annos.__getstate__() for annos in ro_annos]
            clip_data.setdefault(
                "annotations", {}).setdefault("ro", {})[frame] = ro_annos

        for frame in self.__rpa.annotation_api.get_rw_frames(clip):
            rw_anno = \
                self.__rpa.annotation_api.get_rw_annotation(clip, frame)
            clip_data.setdefault(
                "annotations", {}).setdefault("rw", {})[frame] = \
                    rw_anno.__getstate__()

        # Color Corrections
        # RO Clip CCs
        clip_ro_ccs = self.__rpa.color_api.get_ro_ccs(clip)
        clip_ro_ccs = [(None, cc.__getstate__()) for cc in clip_ro_ccs]
        clip_data.setdefault("color_corrections", {}).\
            setdefault("ro", []).extend(clip_ro_ccs)
        # RO Frame CCs
        for frame in self.__rpa.color_api.get_ro_frames(clip):
            clip_ro_ccs = self.__rpa.color_api.get_ro_ccs(clip, frame)
            clip_ro_ccs = [(frame, cc.__getstate__()) for cc in clip_ro_ccs]
            clip_data.setdefault("color_corrections", {}).\
                setdefault("ro", []).extend(clip_ro_ccs)

        # RW Clip CCs
        clip_rw_ccs = self.__rpa.color_api.get_rw_ccs(clip)
        clip_rw_ccs = [(None, cc.__getstate__()) for cc in clip_rw_ccs]
        clip_data.setdefault("color_corrections", {}).\
            setdefault("rw", []).extend(clip_rw_ccs)
        # RW Frame CCs
        for frame in self.__rpa.color_api.get_rw_frames(clip):
            clip_rw_ccs = self.__rpa.color_api.get_rw_ccs(clip, frame)
            clip_rw_ccs = [(frame, cc.__getstate__()) for cc in clip_rw_ccs]
            clip_data.setdefault("color_corrections", {}).\
                setdefault("rw", []).extend(clip_rw_ccs)

        return clip_data

    def __toggle_bg_mode(self, state, mode):
        if state:
            self.__session_api.set_bg_mode(mode)
        else:
            self.__session_api.set_bg_mode(0)

    def __toggle_wipe(self, state):
        self.__toggle_bg_mode(state, 1)

    def __toggle_side_by_side(self, state):
        self.__toggle_bg_mode(state, 2)

    def __toggle_top_to_bottom(self, state):
        self.__toggle_bg_mode(state, 3)

    def __toggle_pip(self, state):
        self.__toggle_bg_mode(state, 4)

    def __swap_background(self):
        self.__session_api.set_fg_playlist(
            self.__session_api.get_bg_playlist())

    def __bg_mode_changed(self, out:bool, mode:int):
        self.__uncheck_checkboxes()
        if mode > 0:
            self.__mode_to_action[mode].setChecked(True)

    def __bg_playlist_changed(self, id):
        if id is None:
            self.__enable_actions(False)
            self.__uncheck_checkboxes()
        else:
            self.__enable_actions(True)
            self.__bg_mode_changed(True, self.__session_api.get_bg_mode())

    def __enable_actions(self, state):
        for action in [
            self.actions.turn_off_background,
            self.actions.wipe, self.actions.pip,
            self.actions.side_by_side, self.actions.top_to_bottom,
            self.actions.swap_background]:
            action.setEnabled(state)

    def __uncheck_checkboxes(self):
        for action in [
            self.actions.wipe, self.actions.pip,
            self.actions.side_by_side, self.actions.top_to_bottom]:
            action.setChecked(False)
